//流程模块【receipt.回执确认】下录入页面自定义js页面,初始函数
function initbodys(){
	var sm = js.request('def_explain');
	//alert(sm);
}