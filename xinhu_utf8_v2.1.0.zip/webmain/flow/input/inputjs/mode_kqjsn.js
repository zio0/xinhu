//流程模块【kqjsn.考勤机设备】下录入页面自定义js页面,初始函数
function initbodys(){
	
}

function changesubmit(d){
	if(d.pinpai=='1'){
		if(d.snip=='')return '中控的需要填写分配的ip';
		if(d.snport=='')return '中控的需要填写分配端口号';
	}
}