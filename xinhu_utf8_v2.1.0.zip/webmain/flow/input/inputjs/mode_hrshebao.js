//流程模块【hrshebao.社保公积金】下录入页面自定义js页面,初始函数
function initbodys(){
	
}