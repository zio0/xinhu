//流程模块【custappy.客户申请使用】下录入页面自定义js页面,初始函数
function initbodys(){
	
}