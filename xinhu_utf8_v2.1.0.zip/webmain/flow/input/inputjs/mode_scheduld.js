//流程模块【scheduld.日程待办】下录入页面自定义js页面,初始函数
function initbodys(){
	
}